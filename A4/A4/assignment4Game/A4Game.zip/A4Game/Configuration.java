package assignment4Game;

public class Configuration {
	
	public int[][] board;
	public int[] available;
	boolean spaceLeft;
	
	public Configuration(){
		board = new int[7][6];
		available = new int[7];
		spaceLeft = true;
	}
	
	public void print(){
		System.out.println("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |");
		System.out.println("+---+---+---+---+---+---+---+");
		for (int i = 0; i < 6; i++){
			System.out.print("|");
			for (int j = 0; j < 7; j++){
				if (board[j][5-i] == 0){
					System.out.print("   |");
				}
				else{
					System.out.print(" "+ board[j][5-i]+" |");
				}
			}
			System.out.println();
		}
	}
	
	public void addDisk (int index, int player){
		// ADD YOUR CODE HERE
		if(spaceLeft&&available[index]<6) {
			board[index][available[index]] = player;
			this.available[index]++;
			int space = 0;
			for(int i=0;i<7;i++) {
				space = space+available[i];
			}
			if(space==42) {
				spaceLeft = false;
			}
		}
	}
	
	public boolean isWinning (int lastColumnPlayed, int player){
		// ADD YOUR CODE HERE
		int row = 0;
		int column = lastColumnPlayed;
		for(int i=0;i<6;i++) {
			if(board[column][i]==player) {
				row = i;
			}
		}
		//horizontal
		for(int i=0;i<=3;i++) {
			if(board[i][row]==player&&board[i+1][row]==player&&board[i+2][row]==player&&board[i+3][row]==player) {
				return true;
			}
		}
		//vertical
		if(row>=3) {
			if(board[column][row]==player&&board[column][row-1]==player&&board[column][row-2]==player&&board[column][row-3]==player) {
				return true;
			}
		}
		//diagonal bottom left to top right
		for(int i=0;i<=3;i++) {
			for(int j=0;j<=2;j++) {
				if(board[i][j]==player&&board[i+1][j+1]==player&&board[i+2][j+2]==player&&board[i+3][j+3]==player) {
					return true;
				}
			}
		}
		//diagonal to left to bottom right
		for(int i=0;i<=3;i++) {
			for(int j=5;j>=3;j--) {
				if(board[i][j]==player&&board[i+1][j-1]==player&&board[i+2][j-2]==player&&board[i+3][j-3]==player) {
					return true;
				}
			}
		}
		return false; // DON'T FORGET TO CHANGE THE RETURN
	}

	public void removeDisk (int index){
			board[index][available[index]-1] = 0;
			this.available[index]--;
			if(!spaceLeft) {
				spaceLeft = true;
			}
	}
	
	public int canWinNextRound (int player){
		// ADD YOUR CODE HERE
		int column = -1;
		boolean b = false;
		for(int i=0;i<7;i++) {
			if(available[i]<6) {
				b = true;
				addDisk(i,player);
				if(isWinning(i,player)) {
					column = i;
					if(b) {
						removeDisk(i);
					}
					break;
				}else {
					if(b) {
						removeDisk(i);
					}
				}
			}
		}
		return column; // DON'T FORGET TO CHANGE THE RETURN
	}
	
	public Configuration copyCon(Configuration c) {
		Configuration copy = new Configuration();
		for(int i=0;i<6;i++) {
			for(int j=0;j<5;j++) {
				copy.board[i][j] = c.board[i][j];
			}
			copy.available[i] = c.available[i];
		}
		return copy;
	}
	
	public int canWinTwoTurns (int player){
		// ADD YOUR CODE HERE
		int column = -1;
		int win = 0;
		int p2 = 3-player;
		Configuration copy1 = copyCon(this);
		if(copy1.canWinNextRound(player)==-1) {
			for(int i=0;i<7;i++) {
				win = 0;
				Configuration copy2 = copyCon(copy1);
				copy2.addDisk(i,player);
				if(copy2.canWinNextRound(p2)==-1){
					for(int j=0;j<7;j++) {
						Configuration copy3 = copyCon(copy2);
						copy3.addDisk(j,p2);
						if(copy3.canWinNextRound(player)!=-1) {
							win++;
						}
					}
					if(win==7) {
						column = i;
						return column;
					}
				}
			}
		}
		
		return column; // DON'T FORGET TO CHANGE THE RETURN
	}
	
}
